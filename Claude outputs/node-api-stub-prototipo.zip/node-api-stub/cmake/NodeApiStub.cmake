# Funzioni di supporto di node-api-stub.
# Unica fonte dei simboli: def/node_api.def di node-api-headers (unione di tutte le versioni).

# Legge i nomi esportati da un file .def (salta NAME/EXPORTS/commenti).
function(node_api_read_symbols def_file out_var)
  file(STRINGS "${def_file}" _lines)
  set(_syms "")
  foreach(_l IN LISTS _lines)
    string(STRIP "${_l}" _l)
    if(_l STREQUAL "" OR _l MATCHES "^(NAME|LIBRARY|EXPORTS)" OR _l MATCHES "^;")
      continue()
    endif()
    list(APPEND _syms "${_l}")
  endforeach()
  list(REMOVE_DUPLICATES _syms)
  set(${out_var} "${_syms}" PARENT_SCOPE)
endfunction()

# Genera la stub: ogni funzione stampa il proprio nome e termina il processo.
# Non include gli header: le firme non servono al linker (C non ha mangling) e
# una stub non deve mai essere eseguita. Se lo è, l'errore deve essere evidente.
function(node_api_generate_stub_source out_file symbols)
  set(_body "")
  foreach(_s IN LISTS symbols)
    string(APPEND _body "NODE_API_STUB(${_s})\n")
  endforeach()
  set(_content [=[/* Generato da node-api-stub: non modificare. */
#include <stdio.h>
#include <stdlib.h>

#if defined(_WIN32) && !defined(NODE_API_STUB_STATIC)
#  define NODE_API_STUB_EXPORT __declspec(dllexport)
#elif defined(_WIN32)
#  define NODE_API_STUB_EXPORT
#else
/* default visibility: con la stub statica su ELF il riferimento resta interponibile
   e il loader sceglie la definizione di node (a meno di -Bsymbolic). */
#  define NODE_API_STUB_EXPORT __attribute__((visibility("default")))
#endif

static void node_api_stub_trap(const char* name) {
  fprintf(stderr,
          "node-api-stub: chiamata a '%s'. L'addon e' legato alla stub di link e non "
          "al Node-API del processo host (stub statica con -Bsymbolic, macOS o Windows?).\n",
          name);
  fflush(stderr);
  abort();
}

#define NODE_API_STUB(name) \
  NODE_API_STUB_EXPORT int name(void) { node_api_stub_trap(#name); return 9; }

]=])
  string(APPEND _content "${_body}")
  # Riscrive il file solo se cambia, per non forzare ricompilazioni a ogni configure.
  file(WRITE "${out_file}.tmp" "${_content}")
  configure_file("${out_file}.tmp" "${out_file}" COPYONLY)
endfunction()

# Genera (al configure) l'import library di NODE.EXE per la toolchain corrente:
#   MSVC / clang-cl -> node_api.lib      (lib.exe o llvm-lib)
#   MinGW (GNU/LLVM) -> libnode_api.dll.a (dlltool o llvm-dlltool)
function(node_api_generate_import_library def_file out_dir out_var)
  file(MAKE_DIRECTORY "${out_dir}")
  if(MSVC OR CMAKE_C_SIMULATE_ID STREQUAL "MSVC")
    set(_arch "${CMAKE_C_COMPILER_ARCHITECTURE_ID}")
    string(TOUPPER "${_arch}" _arch)
    if(_arch STREQUAL "X64" OR _arch STREQUAL "AMD64")
      set(_machine X64)
    elseif(_arch STREQUAL "X86")
      set(_machine X86)
    elseif(_arch STREQUAL "ARM64")
      set(_machine ARM64)
    else()
      message(FATAL_ERROR "node-api-stub: architettura MSVC non gestita: '${_arch}'")
    endif()
    set(_out "${out_dir}/node_api.lib")
    execute_process(
      COMMAND "${CMAKE_AR}" /nologo "/def:${def_file}" "/out:${_out}" "/machine:${_machine}" /name:node.exe
      RESULT_VARIABLE _rc OUTPUT_VARIABLE _o ERROR_VARIABLE _e)
  else()
    if(CMAKE_DLLTOOL)
      set(_dlltool "${CMAKE_DLLTOOL}")
    else()
      find_program(_dlltool NAMES llvm-dlltool dlltool x86_64-w64-mingw32-dlltool REQUIRED)
    endif()
    string(TOLOWER "${CMAKE_SYSTEM_PROCESSOR}" _p)
    if(_p MATCHES "^(x86_64|amd64)$" OR (CMAKE_SIZEOF_VOID_P EQUAL 8 AND _p MATCHES "86"))
      set(_machine i386:x86-64)
    elseif(_p MATCHES "^(aarch64|arm64)$")
      set(_machine arm64)
    elseif(_p MATCHES "^(i.86|x86)$")
      set(_machine i386)
    else()
      message(FATAL_ERROR "node-api-stub: processore MinGW non gestito: '${CMAKE_SYSTEM_PROCESSOR}'")
    endif()
    set(_out "${out_dir}/libnode_api.dll.a")
    execute_process(
      COMMAND "${_dlltool}" -d "${def_file}" -l "${_out}" -D node.exe -m ${_machine}
      RESULT_VARIABLE _rc OUTPUT_VARIABLE _o ERROR_VARIABLE _e)
  endif()
  if(NOT _rc EQUAL 0)
    message(FATAL_ERROR "node-api-stub: generazione import library fallita (${_rc})\n${_o}\n${_e}")
  endif()
  set(${out_var} "${_out}" PARENT_SCOPE)
endfunction()
