# Aggiorna include/ e def/ dal pacchetto npm ufficiale node-api-headers.
#   cmake -DVERSION=1.9.0 -P scripts/update-node-api-headers.cmake
# Non richiede Node.js né npm: scarica il tarball dal registry.
cmake_minimum_required(VERSION 3.18)

if(NOT VERSION)
  message(FATAL_ERROR "Specifica -DVERSION=<x.y.z> di node-api-headers")
endif()
get_filename_component(_root "${CMAKE_CURRENT_LIST_DIR}/.." ABSOLUTE)
set(_tmp "${_root}/.tmp-node-api-headers")
file(REMOVE_RECURSE "${_tmp}")
file(MAKE_DIRECTORY "${_tmp}")

set(_url "https://registry.npmjs.org/node-api-headers/-/node-api-headers-${VERSION}.tgz")
file(DOWNLOAD "${_url}" "${_tmp}/pkg.tgz" STATUS _st TLS_VERIFY ON)
list(GET _st 0 _code)
if(NOT _code EQUAL 0)
  message(FATAL_ERROR "Download fallito: ${_url}\n${_st}")
endif()
file(ARCHIVE_EXTRACT INPUT "${_tmp}/pkg.tgz" DESTINATION "${_tmp}")

file(REMOVE_RECURSE "${_root}/include" "${_root}/def")
file(COPY "${_tmp}/package/include/" DESTINATION "${_root}/include")
file(COPY "${_tmp}/package/def/" DESTINATION "${_root}/def")
file(WRITE "${_root}/def/NODE_API_HEADERS_VERSION" "${VERSION}\n")
file(REMOVE_RECURSE "${_tmp}")
message(STATUS "node-api-headers ${VERSION} vendorizzato in include/ e def/")
