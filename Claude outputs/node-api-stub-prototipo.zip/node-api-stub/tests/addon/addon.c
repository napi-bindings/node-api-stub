#include <node_api.h>

/* Restituisce "real-node-api" se le chiamate arrivano al Node-API dell'host. */
NAPI_MODULE_INIT() {
  napi_value v = NULL;
  if (napi_create_string_utf8(env, "real-node-api", NAPI_AUTO_LENGTH, &v) != napi_ok || v == NULL)
    return exports;
  return v;
}
