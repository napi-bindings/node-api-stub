find_program(NODE_EXECUTABLE node)

function(node_api_test_addon name)
  add_library(${name} MODULE addon/addon.c)
  set_target_properties(${name} PROPERTIES PREFIX "" SUFFIX ".node" C_VISIBILITY_PRESET hidden)
  target_link_libraries(${name} PRIVATE ${ARGN})
endfunction()

# 1. Target consigliato, con le opzioni di link più ostili:
#    -z defs (rifiuta indefiniti) e -Bsymbolic (come go build -buildmode=c-shared).
node_api_test_addon(addon_nodeapi NodeApi::NodeApi)
if(NOT WIN32 AND NOT APPLE)
  target_link_options(addon_nodeapi PRIVATE "LINKER:-z,defs" "LINKER:-Bsymbolic")
endif()

if(NODE_EXECUTABLE)
  add_test(NAME load_nodeapi
    COMMAND ${NODE_EXECUTABLE} -e "const r=require(process.argv[1]); if(r!=='real-node-api'){console.error('got',r);process.exit(1)}"
            $<TARGET_FILE:addon_nodeapi>)
endif()

# 2. Stub statica + -Bsymbolic: deve fallire in modo evidente (abort con messaggio).
if(TARGET node_api_stub AND NOT WIN32 AND NOT APPLE)
  node_api_test_addon(addon_stub_bsymbolic NodeApi::stub)
  target_link_options(addon_stub_bsymbolic PRIVATE "LINKER:-Bsymbolic")
  if(NODE_EXECUTABLE)
    # Il figlio deve terminare con abort() e il messaggio della stub.
    add_test(NAME stub_bsymbolic_traps
      COMMAND ${NODE_EXECUTABLE} -e "const c=require('child_process').spawnSync(process.execPath,['-e','require(process.argv[1])',process.argv[1]],{encoding:'utf8'});process.stderr.write(c.stderr);process.exit(c.signal==='SIGABRT'&&/node-api-stub: chiamata a 'napi_create_string_utf8'/.test(c.stderr)?0:1)"
              $<TARGET_FILE:addon_stub_bsymbolic>)
  endif()
  # 3. Stub statica senza -Bsymbolic: funziona per interposizione ELF.
  node_api_test_addon(addon_stub_interpose NodeApi::stub)
  if(NODE_EXECUTABLE)
    add_test(NAME load_stub_interpose
      COMMAND ${NODE_EXECUTABLE} -e "const r=require(process.argv[1]); if(r!=='real-node-api')process.exit(1)"
              $<TARGET_FILE:addon_stub_interpose>)
  endif()
endif()
