/*
 * Hook di delay-load per addon Node-API su Windows (MSVC / clang-cl).
 *
 * L'import library dichiara i simboli Node-API come importati da "node.exe".
 * Se il processo host ha un altro nome (electron.exe, node rinominato, ...) il
 * caricamento normale fallirebbe: con /DELAYLOAD:node.exe questo hook restituisce
 * il modulo dell'eseguibile corrente (o libnode.dll se presente), da cui il loader
 * risolve i simboli con GetProcAddress.
 * Equivalente in C di win_delay_load_hook.cc di node-gyp.
 */
#if defined(_MSC_VER)

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <delayimp.h>
#include <string.h>

static FARPROC WINAPI node_api_delay_load_hook(unsigned int event, PDelayLoadInfo info) {
  HMODULE m;
  if (event != dliNotePreLoadLibrary) return NULL;
  if (_stricmp(info->szDll, "node.exe") != 0) return NULL;
  m = GetModuleHandleA("libnode.dll");  /* Node compilato come libreria condivisa */
  if (m == NULL) m = GetModuleHandleA(NULL); /* l'eseguibile host */
  return (FARPROC)m;
}

const PfnDliHook __pfnDliNotifyHook2 = node_api_delay_load_hook;

#endif /* _MSC_VER */
